<?php
session_start();
include_once "./config.php";

// ✅ ইউজার লগইন চেক (alogin অথবা user_token)
$userEmail = $_SESSION['alogin'] ?? ($_SESSION['user_token'] ?? null);

if (!$userEmail) {
    $_SESSION['Error'] = "অনুগ্রহ করে লগইন করুন।";
    header("Location: " . BASE_URL . "login.php");
    exit;
}

// ✅ অ্যামাউন্ট চেক
if (!isset($_POST['amount']) || !is_numeric($_POST['amount']) || $_POST['amount'] <= 0) {
    $_SESSION['Error'] = "সঠিক পরিমাণ টাকা দিন।";
    echo BASE_URL . "recharge.php?statusMessage=invalid_amount";
    exit;
}

$amount = floatval($_POST['amount']);

// ✅ Success, Cancel ও Webhook URL তৈরি
$success_url = BASE_URL . "recharge.php?statusMessage=success&id=1";
$cancel_url  = BASE_URL . "recharge.php?statusMessage=error&id=3";
$webhook_url = BASE_URL . "lib/asthapay/execute-payment.php";

// ✅ API ডেটা তৈরি
$data = [
    "cus_name"      => $userEmail,
    "cus_email"     => $userEmail,
    "amount"        => $amount,
    "webhook_url"   => $webhook_url,
    "success_url"   => $success_url,
    "cancel_url"    => $cancel_url,
];

// ✅ API এন্ডপয়েন্ট
$header = [
    "url" => PAYMENT_URL . 'create',
];

// ✅ payment() ফাংশনে API কল
$response = payment($data, $header);

// ✅ রেসপন্স চেক
if (!empty($response)) {
    $res = json_decode($response);

    if (isset($res->status) && $res->status == 1 && !empty($res->payment_url)) {
        // ❗ এখানে "Success" সেশন মেসেজ এখন না দিলে ভালো, কারণ পেমেন্ট এখনও হয়নি
        // তবে যদি Future Use হয় তাহলে রাখতে পারেন (যেমন Amount ধরে রাখা)
        $_SESSION['PendingRechargeAmount'] = $amount;
        echo $res->payment_url;
        exit;
    }
}

// ❌ যদি API ফেইল করে
$_SESSION['Error'] = "পেমেন্ট গেটওয়ের সাথে সংযোগ ব্যর্থ হয়েছে। দয়া করে আবার চেষ্টা করুন।";
echo $cancel_url;
exit;
