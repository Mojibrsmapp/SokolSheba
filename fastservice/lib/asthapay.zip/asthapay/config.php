<?php 
if(!isset($_SESSION)) { 
    session_start(); 
}

define("BASE_URL", "https://grameenseba.xyz/");
define("PAYMENT_URL", "https://secure-pay.nagorikpay.com/api/payment/");

define("APPKEY", "VNdbg4P58ty2xmhai1wqNmQUdbmzAiOkrdJYCadIjb0e0gt9c0");


function payment($data = [], $header = [])
{

    $headers = array(
        'Content-Type: application/json',
        'API-KEY: ' .APPKEY,
    );
    $url = $header['url'];
    $curl = curl_init();
    $data = json_encode($data);

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_VERBOSE => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ));

    $response = curl_exec($curl);
    if (curl_errno($curl)) {
        $error_message = curl_error($curl);
        curl_close($curl);
    } else {
        curl_close($curl);
        return $response;
    }
}