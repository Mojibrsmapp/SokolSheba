<?php
session_start();
ob_start();
include_once "./config.php";

if (!isset($_GET['transactionId'])) {
    die("Transaction ID missing");
}

$trxId = $_GET['transactionId'];

// API কলের জন্য ডাটা তৈরি
$data = [
    "transaction_id" => $trxId,
];

// API endpoint URL
$header = [
    "url" => PAYMENT_URL . 'verify',
];

// payment() ফাংশন কল (আপনার API রিকোয়েস্ট ফাংশন)
$response = payment($data, $header);

// JSON ডিকোড
$data = json_decode($response);

if (!empty($data) && isset($data->status) && $data->status === 'COMPLETED') {
    include('../../includes/db.php');
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ডাটাবেজে আপডেট করার জন্য ডাটা প্রস্তুত
    $deposit = $data->amount ?? 0;
    $token = $data->cus_email ?? '';

    // পেমেন্ট স্ট্যাটাস যাচাই
    if (
        (!isset($data->statusMessage) || $data->statusMessage !== 'Successful') ||
        (!isset($data->transactionStatus) || strtolower($data->transactionStatus) !== 'completed')
    ) {
        $_SESSION['Error'] = "পেমেন্ট হয়নি।";
        header("Location: ../../recharge.php?statusMessage=error&id=2");
        exit;
    } else {
        // ইউজারের ব্যালেন্স আপডেট
        $sql = "UPDATE users SET balance = balance + :amount WHERE token = :token";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':amount', $deposit);
        $stmt->bindParam(':token', $token);
        $stmt->execute();

        // ট্রানজেকশন ইনসার্ট
        $sqlInsert = "INSERT INTO transactions 
            (token, paymentID, trxID, transactionStatus, paymentExecuteTime, merchantInvoiceNumber, customerMsisdn, amount) 
            VALUES (:token, :paymentID, :trxID, :status, :executeTime, :invoiceNumber, :msisdn, :amount)";

        $insertStmt = $dbh->prepare($sqlInsert);
        $insertStmt->bindParam(':token', $token);
        $insertStmt->bindParam(':paymentID', $data->payment_method ?? '');
        $insertStmt->bindParam(':trxID', $data->transaction_id ?? '');
        $insertStmt->bindParam(':status', $data->status ?? '');
        $insertStmt->bindParam(':executeTime', $data->payment_time ?? date('Y-m-d H:i:s'));
        $insertStmt->bindParam(':invoiceNumber', $data->merchant_invoice ?? '');
        $insertStmt->bindParam(':msisdn', $data->cus_email ?? '');
        $insertStmt->bindParam(':amount', $deposit);
        $insertStmt->execute();

        $_SESSION['Success'] = $deposit . " টাকা সফলভাবে রিচার্জ হয়েছে।";
        header("Location: ../../recharge.php?statusMessage=success&id=1");
        exit;
    }
} else {
    $_SESSION['Error'] = "পেমেন্ট যাচাইতে সমস্যা হয়েছে।";
    header("Location: ../../recharge.php?statusMessage=error&id=4");
    exit;
}
